Ain-Shams university Computer Science Structured programming project 
_____________________________________________________________________


The Project is Sonic game included all structured programming principles 
using SFML (Simple fast multimedia library) and C++ programming language .



